const fileInput=document.getElementById("chartFile");
const preview=document.getElementById("preview");
const fileLabel=document.getElementById("fileLabel");
const button=document.getElementById("analyzeBtn");
let selectedFile=null;

fileInput.addEventListener("change",()=>{
  selectedFile=fileInput.files?.[0]||null;
  if(!selectedFile)return;
  if(!["image/png","image/jpeg","image/webp"].includes(selectedFile.type)){showToast("Choose a PNG, JPG or WEBP image.");return;}
  if(selectedFile.size>5*1024*1024){showToast("Please choose an image smaller than 5 MB.");return;}
  fileLabel.textContent=selectedFile.name;
  const url=URL.createObjectURL(selectedFile);
  preview.innerHTML="";
  const img=document.createElement("img");img.src=url;img.alt="Selected trading chart screenshot";preview.appendChild(img);
});

button.addEventListener("click",async()=>{
  if(!selectedFile){showToast("Upload a chart screenshot first.");return;}
  button.disabled=true;button.textContent="Analyzing…";
  document.getElementById("runStatus").textContent="Running three models";
  document.getElementById("overallStatus").textContent="Analysis in progress";
  document.getElementById("overviewText").textContent="Waiting for independent model responses.";
  for(const id of ["gemini","groq","openrouter"]){setState(id,"Running…");document.getElementById(id+"Result").textContent="Analyzing the uploaded image…";}
  try{
    const dataUrl=await readAsDataURL(selectedFile);
    const response=await fetch("/.netlify/functions/analyze",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({
      symbol:document.getElementById("symbol").value.trim(),
      timeframe:document.getElementById("timeframe").value,
      mimeType:selectedFile.type,
      imageBase64:dataUrl.split(",")[1]
    })});
    const data=await response.json();
    if(!response.ok)throw new Error(data.error||"Analysis request failed.");
    for(const name of ["gemini","groq","openrouter"]){
      const item=data.models?.[name];
      setState(name,item?.ok?"Complete":"Unavailable");
      document.getElementById(name+"Result").textContent=item?.text||item?.error||"No response.";
    }
    document.getElementById("overallStatus").textContent="Independent analyses returned";
    document.getElementById("overviewText").textContent=data.summary||"Compare the three explanations. Differences and uncertainty matter; this prototype does not generate trade instructions.";
    document.getElementById("runStatus").textContent="Completed";
  }catch(err){
    document.getElementById("overallStatus").textContent="Could not complete analysis";
    document.getElementById("overviewText").textContent=err.message;
    document.getElementById("runStatus").textContent="Error";
    showToast(err.message);
  }finally{button.disabled=false;button.textContent="Analyze chart";}
});

function setState(id,text){document.getElementById(id+"State").textContent=text;}
function readAsDataURL(file){return new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsDataURL(file);});}
function showToast(message){const t=document.getElementById("toast");t.textContent=message;t.style.display="block";setTimeout(()=>t.style.display="none",3500);}
