# EL NINO ANALYZER — starter prototype

A responsive screenshot-analysis web app using Gemini, Groq and OpenRouter through a Netlify serverless function.

## Important limitations
- This is an educational chart-reading prototype, not a trading system or financial advice.
- It does not place trades or produce buy/sell/entry/stop-loss/take-profit instructions.
- The models describe visible evidence only. They must not invent POC/VAH/VAL, VWAP or exact prices.
- A normal chart screenshot cannot prove bid/ask order flow. Real order-flow analysis needs suitable underlying market data.
- CTR is left unassessed until its meaning is defined.
- Free API access is subject to each provider's changing quotas, model availability and rate limits. OpenRouter's `openrouter/free` may route to a model that changes and may not always support image input.

## Deploy
1. Create a Netlify account and a new site from this folder/repository.
2. In Netlify Site configuration → Environment variables, add `GEMINI_API_KEY`, `GROQ_API_KEY`, and `OPENROUTER_API_KEY`.
3. Optionally add `SITE_URL` and model overrides from `.env.example`.
4. Deploy the site. Netlify will publish the static files and the function at `/.netlify/functions/analyze`.
5. Open the deployed site, upload a chart image under 5 MB and select Analyze chart.

## Local development
Install Node.js and Netlify CLI, then run:
`netlify dev`

## Security
API keys are read only by the serverless function. Do not paste keys into `app.js`, `index.html`, or any public frontend file. If a key is exposed, revoke it and create a replacement.

## Provider references
- Gemini image input: https://ai.google.dev/api/generate-content
- Groq vision: https://console.groq.com/docs/vision
- OpenRouter vision models: https://openrouter.ai/collections/vision-models
- OpenRouter free models and limits: https://openrouter.ai/collections/free-models/
