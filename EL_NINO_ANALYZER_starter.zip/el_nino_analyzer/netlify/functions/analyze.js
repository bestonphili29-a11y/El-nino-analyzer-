const headers = {"Content-Type":"application/json"};

const SYSTEM_PROMPT = `You are an educational chart-reading assistant. Inspect the supplied trading-chart screenshot and explain only what is visibly supported. Do not tell the user to buy, sell, enter, exit, or place an order. Do not provide personalized financial advice, guaranteed outcomes, win probabilities, or invented prices.
Return concise plain text with these headings:
1) Visible market structure (only if identifiable)
2) Volume Profile (POC/VAH/VAL only if actually visible; do not calculate from pixels)
3) VWAP (only if clearly visible)
4) Liquidity sweep (say possible/unclear, not confirmed, unless evidence is clear)
5) Order flow (state that screenshot candles/ordinary volume cannot establish true bid/ask order flow; identify required data)
6) CTR (state “Not assessed — user definition required”)
7) Evidence gaps and uncertainty
Be explicit when a feature is absent or unreadable. A screenshot alone cannot provide reliable exact market data.`;

function json(statusCode, body){return {statusCode,headers,body:JSON.stringify(body)};}
function extractGemini(data){return data?.candidates?.[0]?.content?.parts?.map(p=>p.text||"").join("\n")||"No text returned.";}

exports.handler = async (event) => {
  if(event.httpMethod!=="POST") return json(405,{error:"Use POST."});
  let body;
  try{body=JSON.parse(event.body||"{}");}catch{return json(400,{error:"Invalid JSON."});}
  const {symbol="Unspecified",timeframe="Unspecified",mimeType,imageBase64}=body;
  if(!imageBase64 || !["image/png","image/jpeg","image/webp"].includes(mimeType)) return json(400,{error:"A PNG, JPG or WEBP chart image is required."});
  if(imageBase64.length>7_000_000) return json(413,{error:"Image is too large. Use an image under 5 MB."});

  const prompt=`${SYSTEM_PROMPT}\nChart symbol: ${String(symbol).slice(0,24)}. Timeframe: ${String(timeframe).slice(0,8)}. Give an independent visual assessment.`;

  const tasks = {
    gemini: async()=>{
      if(!process.env.GEMINI_API_KEY) throw new Error("GEMINI_API_KEY is not configured.");
      const model=process.env.GEMINI_MODEL||"gemini-2.5-flash";
      const r=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${process.env.GEMINI_API_KEY}`,{
        method:"POST",headers:{"Content-Type":"application/json"},
        body:JSON.stringify({contents:[{parts:[{text:prompt},{inline_data:{mime_type:mimeType,data:imageBase64}}]}],generationConfig:{temperature:0.2,maxOutputTokens:1200}})
      });
      const d=await r.json();if(!r.ok)throw new Error(d.error?.message||`Gemini HTTP ${r.status}`);
      return extractGemini(d);
    },
    groq: async()=>{
      if(!process.env.GROQ_API_KEY) throw new Error("GROQ_API_KEY is not configured.");
      const r=await fetch("https://api.groq.com/openai/v1/chat/completions",{
        method:"POST",headers:{"Authorization":`Bearer ${process.env.GROQ_API_KEY}`,"Content-Type":"application/json"},
        body:JSON.stringify({model:process.env.GROQ_MODEL||"qwen/qwen3.8-27b",messages:[{role:"user",content:[{type:"text",text:prompt},{type:"image_url",image_url:{url:`data:${mimeType};base64,${imageBase64}`}}]}],temperature:0.2,max_completion_tokens:1200})
      });
      const d=await r.json();if(!r.ok)throw new Error(d.error?.message||`Groq HTTP ${r.status}`);
      return d.choices?.[0]?.message?.content||"No text returned.";
    },
    openrouter: async()=>{
      if(!process.env.OPENROUTER_API_KEY) throw new Error("OPENROUTER_API_KEY is not configured.");
      const r=await fetch("https://openrouter.ai/api/v1/chat/completions",{
        method:"POST",headers:{"Authorization":`Bearer ${process.env.OPENROUTER_API_KEY}`,"Content-Type":"application/json","HTTP-Referer":process.env.SITE_URL||"https://example.netlify.app","X-Title":"EL NINO ANALYZER"},
        body:JSON.stringify({model:process.env.OPENROUTER_MODEL||"openrouter/free",messages:[{role:"user",content:[{type:"text",text:prompt},{type:"image_url",image_url:{url:`data:${mimeType};base64,${imageBase64}`}}]}],temperature:0.2,max_tokens:1200})
      });
      const d=await r.json();if(!r.ok)throw new Error(d.error?.message||`OpenRouter HTTP ${r.status}`);
      return d.choices?.[0]?.message?.content||"No text returned.";
    }
  };

  const entries=await Promise.all(Object.entries(tasks).map(async([name,fn])=>{
    try{return [name,{ok:true,text:await fn()}];}
    catch(e){return [name,{ok:false,error:e.message}];}
  }));
  const models=Object.fromEntries(entries);
  const success=Object.values(models).filter(x=>x.ok).length;
  return json(200,{models,summary:`${success} of 3 AI providers responded. Compare their evidence and note any disagreements. This tool is educational and does not produce trade instructions.`});
};
